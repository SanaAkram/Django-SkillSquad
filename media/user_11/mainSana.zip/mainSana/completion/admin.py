from django.contrib import admin
from completion.models import Completion

# Register your models here.
admin.site.register(Completion)