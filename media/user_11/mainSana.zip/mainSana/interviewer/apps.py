from django.apps import AppConfig


class InterviewerConfig(AppConfig):
    name = 'interviewer'
